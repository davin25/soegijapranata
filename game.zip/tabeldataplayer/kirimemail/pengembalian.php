<?php
	
	// include "conn.php";
	// include "style.php";

	$server = 'localhost';
	$user = 'root';
	$password = 'sur4t*_*xxx';
	$db = 'meranti';
	$conn = mysql_connect($server, $user, $password);
	mysql_select_db($db);

	// var_dump($conn);

	require_once('class.phpmailer.php');

	// define('GUSER', 'care@unika.ac.id'); // GMail username	
	define('GUSER', 'sirkulasi.perpustakaan@unika.ac.id'); // GMail username
	define('GPWD', 's1rkul451'); // GMail password


	function smtpmailer($to, $from, $from_name, $subject, $body) {
		$mail = new PHPMailer();  // create a new object
		$mail->IsSMTP(); // enable SMTP
		$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only
		$mail->SMTPAuth = true;  // authentication enabled
		$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 465;

		$mail->Username = GUSER;
		$mail->Password = GPWD;
		$mail->SetFrom($from, $from_name);
		$mail->Subject = $subject;
		$mail->Body = $body;
		$mail->IsHTML(true);
		//$mail->AddAddress($to);

		$addr = explode(',',$to);

		foreach ($addr as $address) {
			$mail->AddAddress($address);
		}


		if(!$mail->Send()) {
			$GLOBALS['error'] = 'Mail error: '.$mail->ErrorInfo;
			echo 'Mail error: '.$mail->ErrorInfo;;
			echo $to;
			return false;
		} else {
			$GLOBALS['error'] = "";
			return true;
		}
	}

	$date = date('Y-m-d');
	// echo $date;
	$tomorrow = date("Y-m-d", strtotime("+1 day"));
	// $tomorrow = '2019-06-24';
	// echo $tomorrow;
	$sql_get_member = "SELECT DISTINCT 
							loan.member_id,
							member.member_email
						FROM 
							loan 
							LEFT JOIN item
								ON loan.item_code = item.item_code
							LEFT JOIN biblio
								ON item.biblio_id = biblio.biblio_id
							LEFT JOIN member
								ON loan.member_id = member.member_id
						WHERE 
							YEAR(loan_date) > '2018' 
							AND is_return = 0 
							AND due_date = '$tomorrow'
						GROUP BY 
							loan.member_id
						ORDER BY
							due_date DESC
						-- LIMIT 1
						";
	// echo $sql_get_member;
	$query_get_member = mysql_query($sql_get_member);
	$j=0;
	while ($row_get_member = mysql_fetch_array($query_get_member)) {
		$j++;
		// echo $j."</br>";
		$member_id = $row_get_member['member_id'];

		$email = $row_get_member['member_email'];
	 	$from = '<care@unika.ac.id>';
	 	// $from = '<sirkulasi.perpustakaan@unika.ac.id>';
        $to = $email;
        $sql = "SELECT 
					member.member_id,
					member.member_name,
					item.item_code,
					biblio.title,
					loan.loan_date,
					loan.due_date 
				FROM 
					loan 
					LEFT JOIN item
						ON loan.item_code = item.item_code
					LEFT JOIN biblio
						ON item.biblio_id = biblio.biblio_id
					LEFT JOIN member
						ON loan.member_id = member.member_id
				WHERE 
					loan.is_return = 0 
					AND loan.due_date = '$tomorrow'
					AND loan.member_id = '$member_id'
				";
		$query = mysql_query($sql);
		$table;
		$table = "<table class='table'>";
		$table = $table." <tr><th>No</th><th>Member ID</th><th>Member Name</th><th>Kode Buku</th><th>Judul Buku</th><th>Tanggal Pinjam</th><th>Tanggal Kembali</th></tr>";
		$i = 0;
		while ($row = mysql_fetch_array($query)) {
			$date_now = date('Y-m-d');
			$i ++;
			$member_id = $row['member_id'];
			$member_name = $row['member_name'];
			$item_code = $row['item_code'];
			$judul_buku = $row['title'];
			$loan_date = date('d-M-Y', strtotime($row['loan_date']));
			$due_date = date('d-M-Y', strtotime($row['due_date']));


			$table = $table." <tr>";
			$table = $table." <td>".$i."</td>";
			$table = $table." <td>".$member_id."</td>";
			$table = $table." <td>".$member_name."</td>";
			$table = $table." <td>".$item_code."</td>";
			$table = $table." <td>".$judul_buku."</td>";
			$table = $table." <td>".$loan_date."</td>";
			$table = $table." <td>".$due_date."</td>";
			$table = $table." </tr>";
		}
		$table = $table." </table>";
		// echo $email."<br>";

        $subject = 'Masa Berlaku Peminjaman Buku (do not reply)';
    	$tanggal = date('d-M-Y', strtotime($tomorrow));
		$body = "Berdasarkan data peminjaman buku, ada buku yang harus Anda kembalikan atau perpanjang pada tanggal ".$tanggal.":" ."<br><br>".$table."<br><br>Silahkan Anda mengunjungi Ruang Sirkulasi (Lantai 3 Gedung Thomas Aquinas) untuk pengembalian atau perpanjang masa pinjam buku tersebut.<br><br>Terima Kasih.<br></br>Salam Literasi Perpustakaan Unika Soegijapranata<br><br>";

        echo $body;
        smtpmailer($to, 'sirkulasi.perpustakaan@unika.ac.id', 'Perpustakaan Unika', $subject, $body);
        // smtpmailer('andre.kurniawan@unika.ac.id', 'sirkulasi.perpustakaan@unika.ac.id', 'Perpustakaan Unika', $subject, $body);
	}
?>