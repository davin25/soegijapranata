<?php
	
	// include "conn.php";
	// include "style.php";

	$server = 'localhost';
	$user = 'root';
	$password = 'sur4t*_*xxx';
	$db = 'meranti';
	$conn = mysqli_connect($server, $user, $password, $db);

	// var_dump($conn);

	require_once('class.phpmailer.php');

	// define('GUSER', 'care@unika.ac.id'); // GMail username	
	define('GUSER', 'perpustakaan@unika.ac.id'); // GMail username
	define('GPWD', 'lyravanooke'); // GMail password


	function smtpmailer($to, $from, $from_name, $subject, $body) {
		$mail = new PHPMailer();  // create a new object
		$mail->IsSMTP(); // enable SMTP
		$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only
		$mail->SMTPAuth = true;  // authentication enabled
		$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 465;

		$mail->Username = GUSER;
		$mail->Password = GPWD;
		$mail->SetFrom($from, $from_name);
		$mail->Subject = $subject;
		$mail->Body = $body;
		$mail->IsHTML(true);
		//$mail->AddAddress($to);

		$addr = explode(',',$to);

		foreach ($addr as $address) {
			$mail->AddAddress($address);
		}


		if(!$mail->Send()) {
			$GLOBALS['error'] = 'Mail error: '.$mail->ErrorInfo;
			echo 'Mail error: '.$mail->ErrorInfo;;
			echo $to;
			return false;
		} else {
			$GLOBALS['error'] = "";
			return true;
		}
	}
	$date = date("Y-m-d");
	// echo $date;
	$sql_member = "SELECT * FROM member WHERE expire_date > '$date' AND member_email !='' AND member_id LIKE '%18.O1.%' LIMIT 10";
	$query_member = mysqli_query($conn,$sql_member);
	$i=0;
	while ($row_member = mysqli_fetch_array($query_member)) {
		$i++;
		// echo $i." ";
		echo $row_member['member_email']."</br>";
		$subject = 'Pengumuman Libur Natal dan Tahun baru Perpustakaan Unika Soegijapranata (do not reply)';
    	$tanggal = date('d-M-Y', strtotime($tomorrow));
		$body = "Halo teman-teman<br>
				Anggota Perpustakaan Unika Soegijapranata<br><br>

				Sehubungan dengan libur Natal 2023 dan Tahun Baru 2024, maka perpustakaan tutup mulai tanggal 23 Desember 2019 sd 1 Januari 2020. <br>
				Layanan perpustakaan mulai buka kembali pada tgl. 2 Januari 2020 pukul 08.00-15.30, terima kasih.<br> <br>
				Salam Perpustakaan Unika Soegijapranata";

		$to = $row_member['member_email'];
        // echo $body;
        smtpmailer($to, 'perpustakaan@unika.ac.id', 'Perpustakaan Unika', $subject, $body);
	}
?>