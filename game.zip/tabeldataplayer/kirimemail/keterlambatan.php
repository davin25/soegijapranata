
<?php
	
	include "../conn.php";
	// include "style.php";
	$admin = $_POST["admin"];
	$tanggal_proses = date("Y-m-d H:i:s");
	// $server = 'localhost';
	// $user = 'root';
	// $password = 'Seringlup4#123';
	// $db = 'meranti';
	// $conn = mysqli_connect($server, $user, $password, $db);

	// var_dump($conn);

	require_once('class.phpmailer.php');

	// define('GUSER', 'care@unika.ac.id'); // GMail username	
	define('GUSER', 'sirkulasi.perpustakaan@unika.ac.id'); // GMail username
	define('GPWD', 's1rkul451'); // GMail password


	function smtpmailer($to, $from, $from_name, $subject, $body) 
	{
		$mail = new PHPMailer();  // create a new object
		$mail->IsSMTP(); // enable SMTP
		$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only
		$mail->SMTPAuth = true;  // authentication enabled
		$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 465;

		$mail->Username = GUSER;
		$mail->Password = GPWD;
		$mail->SetFrom($from, $from_name);
		$mail->Subject = $subject;
		$mail->Body = $body;
		$mail->IsHTML(true);
		//$mail->AddAddress($to);

		$addr = explode(',',$to);

		foreach ($addr as $address) {
			$mail->AddAddress($address);
		}


		if(!$mail->Send()) {
			$GLOBALS['error'] = 'Mail error: '.$mail->ErrorInfo;
			echo 'Mail error: '.$mail->ErrorInfo;;
			echo $to;
			return false;
		} else {
			$GLOBALS['error'] = "";
			return true;
		}
	}

	$date = date('Y-m-d');

	$sql_get_member = "SELECT DISTINCT loan.member_id,
	 member.member_email
	  FROM loan LEFT JOIN 
	  item ON loan.item_code = item.item_code 
	  LEFT JOIN biblio ON item.biblio_id = biblio.biblio_id 
	  LEFT JOIN member ON loan.member_id = member.member_id 
	  WHERE YEAR(loan_date) > '2013' AND is_return = 0 AND due_date < '$date' 
	  AND member.member_id not like '58%' GROUP BY loan.member_id";
	$query_get_member = mysqli_query($conn,$sql_get_member);
	$j=0;
	while ($row_get_member = mysqli_fetch_array($query_get_member)) 
	{
		$j++;
		// echo $j."</br>";
		$member_id = $row_get_member['member_id'];

		$email = $row_get_member['member_email'];
	 	// $from = '<care@unika.ac.id>';
	 	$from = '<sirkulasi.perpustakaan@unika.ac.id>';
        $to = $email;
        $sql = "SELECT 
					member.member_id,
					member.member_name,
					item.item_code,
					biblio.title,
					loan.loan_date,
					loan.due_date 
				FROM 
					loan 
					LEFT JOIN item
						ON loan.item_code = item.item_code
					LEFT JOIN biblio
						ON item.biblio_id = biblio.biblio_id
					LEFT JOIN member
						ON loan.member_id = member.member_id
				WHERE 
					loan.is_return = 0 
					AND loan.due_date < '$date'
					AND loan.member_id = '$member_id'";
		$query = mysqli_query($conn,$sql);
		$table;
		$table = "<table class='table table-bordered'>";
		$table = $table." <tr><th>No</th><th>Member ID</th><th>Member Name</th><th>Kode Buku</th><th>Judul Buku</th><th>Tanggal Pinjam</th><th>Tanggal Kembali</th></tr>";
		$i = 0;
		$total_lateness=0;
		while ($row = mysqli_fetch_array($query)) 
		{
			$date_now = date('Y-m-d');
			$i ++;
			$member_id = $row['member_id'];
			$member_name = $row['member_name'];
			$item_code = $row['item_code'];
			$judul_buku = $row['title'];
			$loan_date = date('d-M-Y', strtotime($row['loan_date']));
			$due_date = date('d-M-Y', strtotime($row['due_date']));
			$date1=date_create($due_date);
                            if($due_date < date('Y-m-d'))
                             {
                                $date = date('Y-m-d');
                             
                             }
                             $date2=date_create($date);
                             $diff=date_diff($date1,$date2);
                             $diff = $diff->format("%r%a");
                             // echo "<td>".$diff."</td>"
                             $sunday = 0;
                             $start = new DateTime($due_date);
                             $end   = new DateTime($date);
                             $interval = DateInterval::createFromDateString('1 day');
                             $period = new DatePeriod($start, $interval, $end);
                              foreach ($period as $dt)
                                  {
                                    if ($dt->format('N') == 7)
                                      {
                                          $sunday++;
                                      }
                                  }
                                  // echo "<td>".$sunday."</td>";
                               $saturday = 0;
                               $start = new DateTime($due_date);
                               $end   = new DateTime($date);
                               $interval = DateInterval::createFromDateString('1 day');
                               $period = new DatePeriod($start, $interval, $end);
                               foreach ($period as $dt)
                                  {
                                      if ($dt->format('N') == 6)
                                      {
                                          $saturday++;
                                      }
                                  }
                                  // echo "<td>".$saturday."</td>";
								
                                $sql_holiday = "SELECT COUNT(holiday_id) AS total_holiday FROM holiday WHERE holiday_date BETWEEN '$due_date' AND '$date' AND holiday_date > '2015-04-02' AND holiday_dayname != 'Sun' AND holiday_dayname != 'Sat'";
                              	$query_holiday = mysqli_query($conn, $sql_holiday);
                                $row_holiday = mysqli_fetch_array($query_holiday);
                                $total_holiday = $row_holiday['total_holiday'] + $saturday + $sunday;
                                // echo "<td>".$total_holiday."</td>";
                                 $lateness = $diff - $total_holiday;
								
                                  if($lateness > 0)
                                  {
                                    $total_lateness = $total_lateness + $lateness;
			                        if(substr($member_id, 0,2) == "58")
                                    {
                                      $fines = 0;
                                    } 
				                	else
                                    {
                                      $fines = $lateness * 500;
									  $table = $table." <tr>";
										$table = $table." <td>".$i."</td>";
										$table = $table." <td>".$member_id."</td>";
										$table = $table." <td>".$member_name."</td>";
										$table = $table." <td>".$item_code."</td>";
										$table = $table." <td>".$judul_buku."</td>";
										$table = $table." <td style='color:red;'>".$loan_date."</td>";
										$table = $table." <td style='color:red;'>".$due_date."</td>";
                                    }
								}
		$total_fines = $total_lateness * 500;
			$table = $table." </tr>";
		}
		$table = $table." </table>";
		// echo $email."<br>";
		if ($total_fines >500000){
			$add = "<h4 style='color:green;'> Terkait dengan denda buku, maka kami akan memberikan potongan denda buku sebesar 50% sampai dengan 31 Mei 2023.</h4>";
		}else{
			$add = "";
		}

		function rupiah($total_fines){
	
			$hasil_rupiah = "Rp " . number_format($total_fines,2,',','.');
			return $hasil_rupiah;
		 
		}
		$total_fines = rupiah($total_fines);

        $subject = 'Keterlambatan Peminjaman Buku (do not reply)';

        $header = "<h4 style='color:red;'> Halo, ".$member_name."</h4><br>";
		$body = $header."Kami sampaikan informasi bahwa  masih ada buku Perpustakaan yang belum Anda kembalikan dan melebihi jatuh tempo pengembalian sebagai berikut:" ."<br><br>".$table."<br> <H4 style='color:red;'>Total Denda Buku: ".$total_fines." </H4><br>Sehubungan dengan hal tersebut, mohon untuk buku Perpustakaan bisa dikembalikan,<br>".$add." Untuk detail lebih lanjut silahkan klik link detail denda <a href='https://lib.unika.ac.id/admin/modules/circulation/total_fines_qris.php?id=".$member_id."' target='_blank'>Link Detail Denda<a/><br><br> Waktu pengembalian buku di Lantai 1 Perpustakaan Gd. Thomas Aquinas Senin - Jumat pukul 08:00 - 15:00 WIB.<br><br>Apabila ada yang ingin ditanyakan silakan menghubungi Hotline Perpustakaan: 081225141288<br><br><br>Terima Kasih.<br></br>Salam Literasi Perpustakaan Unika Soegijapranata<br><br>";
		
        echo $body;
		$logdate = date('d-M-Y H:i:s');
		$log_msg = $admin." melakukan proses email notifikasi keterlambatan peminjaman kepada member ".$member_id." - ".$to;
		//$email_msg = $log_msg.". Silahkan untuk mengambil buku di pos satpam dekat ATM 1 jam setelah menerima email ini.";
		$insert_log = "INSERT INTO system_log (log_type, id, log_location, log_msg, log_date) VALUES ('staff', '$admin', 'Email Keterlambatan', '$log_msg', '$tanggal_proses')";
		$query_insert_log = mysqli_query($conn, $insert_log);

        // smtpmailer($to, 'sirkulasi.perpustakaan@unika.ac.id', 'Perpustakaan Unika', $subject, $body);
        if($j == 1)
		{
			smtpmailer('yosua@unika.ac.id', 'sirkulasi.perpustakaan@unika.ac.id', 'Perpustakaan Unika', $subject, $body);
			die;
		}
		else
		{
			die;
		}
        	
	}
?>