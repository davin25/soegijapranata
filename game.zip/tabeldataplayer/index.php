
<?php
include_once("config.php");
 
// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM datagame where status = 0");
$result2 = mysqli_query($mysqli, "SELECT * FROM datagame where status = 1");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pemain</title>
<style>

body {font-family: Arial;}

h1 {text-align: center;}
p {text-align: center;}
/* Style the tab */
.tab {
  overflow: hidden;
  background-color: #f1f1f1;
  width: 50%;
  margin-left: auto;
  margin-right: auto;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border-top: none;
}
.center {
  margin-left: auto;
  margin-right: auto;
}
#datapemain {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 50%;
}

#datapemain td, #datapemain th {
  border: 1px solid #ddd;
  padding: 8px;
}

#datapemain tr:nth-child(even){background-color: #f2f2f2;}

#datapemain tr:hover {background-color: #ddd;}

#datapemain th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #f2f2f2;
  color: black;
}
</style>
</head>
<body>
    <h1>Data Pemain</h1>
        <p>untuk mengkonfirmasi jika pemain sudah mengkontak perpustakaan dan menerima hadiah</p>
        <p>✅ =  pemain sudah kontak dengan perpustakaan dan menerima hadiah</p>
        <p>❌ = pemain sudah kontak perpustakaan tetapi pemain belum menerima hadiah </p>
        <div class="tab">
          <button class="tablinks" onclick="openCity(event, 'tblstatus1')">Belum Menerima Hadiah</button>
          <button class="tablinks" onclick="openCity(event, 'tblstatus2')">Sudah Menerima Hadiah</button>
        </div>
        
    <div id="tblstatus1" class="tabcontent">    
    <table id="datapemain" class="center">
        <tr>
            <th>Nama</th> <th>Email</th> <th>ID md5</th> <th>Update Terakhir(GMT +0)</th> <th>Status</th> <th></th>
        </tr>
        <?php  
        while($user_data = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$user_data['nama']."</td>";
            echo "<td>".$user_data['email']."</td>";
            echo "<td>".$user_data['md5id']."</td>";
            echo "<td>".$user_data['timeofupdate']."</td>";
            echo "<td>❌</td>"; 
            echo "<td><a href='editstatusto1.php?id=$user_data[id]'>konfirmasi</a></td></tr>";  
        }
        ?>
    </table>
    </div>
    
    <div id="tblstatus2" class="tabcontent">    
    <table id="datapemain" class="center">
        <tr>
            <th>Nama</th> <th>Email</th> <th>ID md5</th> <th>Update Terakhir(GMT +0)</th> <th>Status</th> <th></th>
        </tr>
        <?php  
        while($user_data = mysqli_fetch_array($result2)) {         
            echo "<tr>";
            echo "<td>".$user_data['nama']."</td>";
            echo "<td>".$user_data['email']."</td>";
            echo "<td>".$user_data['md5id']."</td>";
            echo "<td>".$user_data['timeofupdate']."</td>";
            echo "<td>✅</td>"; 
            echo "<td><a href='editstatusto0.php?id=$user_data[id]'>reset status</a></td></tr>"; 
        }
        ?>
    </table>
    </div>
<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
</body>
</html>