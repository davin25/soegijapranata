<?php

		require_once('/kirimemail/class.phpmailer.php');
		// koneksi database
        include_once("config.php");
		// define('GUSER', 'loan.online@unika.ac.id'); // GMail username
		// define('GPWD', 'unika12345'); // GMail password
		$nama = $_POST['nama'];
		$email = $_POST['email'];
		$md5id = md5($_POST['email']);
		$to = $email;
		$duplicate=mysqli_query($mysqli,"select * from datagame where email='$email'");
		if (mysqli_num_rows($duplicate)>0){
		
		}
		else
		{
			mysqli_query($mysqli, "INSERT INTO datagame(nama,email,md5id,timeofupdate,status) VALUES('$nama','$email','$md5id',now(),0)");
			define('GUSER', 'loan.online@unika.ac.id'); // GMail username
			define('GPWD', 'unika12345'); // GMail password
			function smtpmailer($to, $from, $from_name, $subject, $body) {
				$mail = new PHPMailer();  // create a new object
				$mail->IsSMTP(); // enable SMTP
				$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only
				$mail->SMTPAuth = true;  // authentication enabled
				$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
				$mail->Host = 'smtp.gmail.com';
				$mail->Port = 465;

				$mail->Username = GUSER;
				$mail->Password = GPWD;
				$mail->SetFrom($from, $from_name);
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsHTML(true);
				//$mail->AddAddress($to);
				$addr = explode(',',$to);

				foreach ($addr as $address) {
					$mail->AddAddress($address);
				}


				if(!$mail->Send()) {
					$GLOBALS['error'] = 'Mail error: '.$mail->ErrorInfo;
					echo 'Mail error: '.$mail->ErrorInfo;;
					echo $to;
					return false;
				} else {
					$GLOBALS['error'] = "";
					return true;
				}
			}
			$body='<html>
<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #ffffff;" class="email-bg">
        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
	        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
                <tr>
                    <td style="background-color: #dddddd;" class="darkmode-bg">
						<br></br>
                        <img src=".../images/logo_unika.png" width="200" height="" alt="alt_text" border="0" style="width: 100%; max-width: 200px; height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 15px; color: #555555; margin: auto; display: block;" class="g-img">
						<br></br>
					</td>
                </tr>
                <tr>
                    <td style="background-color: #ffffff;" class="darkmode-bg">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                            <tr>
                                <td style="padding: 20px; font-family: sans-serif; font-size: 15px; line-height: 20px; color: #555555;">    
                                    <h3 align="center">Selamat, anda berhak mendapat merchandise dari perpustakaan </h3>
									<h2 style="color: #000000;" align="center">'.$_POST['nama'].'</h2>
									<h3 style="color: #333333;" align="center">ID: '.md5($_POST['email']).'</h3>
                                    <h3 align="center">Silakan menghubungi hotline Perpustakaan</h3>
                                    <center>
                                    <a align="center" href="https://api.whatsapp.com/send?phone=6281225141288"><img src=".../images/perpushotline.png"></a>
                                    </center>
								</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr style="background-color:grey;" align="center" >
                    <td style="padding: 20px; font-family: sans-serif; font-size: 12px; line-height: 15px; text-align: center; color: #ffffff;">
						Universitas Katolik Soegijapranata<br><span class="unstyle-auto-detected-links">Jl. Pawiyatan Luhur IV/1,<br>Bendan Duwur, Kec. Gajahmungkur, Kota Semarang, Jawa Tengah 50234<br>(024) 850-5003, (024) 850-0223</span>
                        <br><br>
                    </td>
                </tr>
        </div>
</body>
</html>';

			smtpmailer($to, 'loan.online@unika.ac.id', 'Perpustakaan Unika', $subject, $body);


// 			$mail = new PHPMailer;
// 			$mail->isSMTP(); 
// 			$mail->SMTPDebug = 1; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
// 			$mail->Host = gethostbyname('smtp.gmail.com'); // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
// 			$mail->Port = 465; // TLS only
// 			$mail->SMTPSecure = 'ssl'; // ssl is deprecated
// 			$mail->SMTPAuth = true;
// 			$mail->Username = 'loan.online@unika.ac.id'; // email
// 			$mail->Password = 'unika12345'; // password
// 			$mail->setFrom('loan.online@unika.ac.id', 'Perpustakaan Unika'); // From email and name
// 			$mail->addAddress($email, 'pemain'); // to email and name
// 			$mail->Subject = 'Bukti Tuntas Game [Mengenal Perpus Bersama Kak Lita]';
// 			$mail->IsHTML(true);
// 			$mail->Body='<html>
// <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #ffffff;" class="email-bg">
//         <div style="max-width: 600px; margin: 0 auto;" class="email-container">
// 	        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
//                 <tr>
//                     <td style="background-color: #dddddd;" class="darkmode-bg">
// 						<br></br>
//                         <img src=".../images/logo_unika.png" width="200" height="" alt="alt_text" border="0" style="width: 100%; max-width: 200px; height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 15px; color: #555555; margin: auto; display: block;" class="g-img">
// 						<br></br>
// 					</td>
//                 </tr>
//                 <tr>
//                     <td style="background-color: #ffffff;" class="darkmode-bg">
//                         <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
//                             <tr>
//                                 <td style="padding: 20px; font-family: sans-serif; font-size: 15px; line-height: 20px; color: #555555;">    
//                                     <h3 align="center">Selamat, anda berhak mendapat merchandise dari perpustakaan </h3>
// 									<h2 style="color: #000000;" align="center">'.$_POST['nama'].'</h2>
// 									<h3 style="color: #333333;" align="center">ID: '.md5($_POST['email']).'</h3>
//                                     <h3 align="center">Silakan menghubungi hotline Perpustakaan</h3>
//                                     <center>
//                                     <a align="center" href="https://api.whatsapp.com/send?phone=6281225141288"><img src=".../images/perpushotline.png"></a>
//                                     </center>
// 								</td>
//                             </tr>
//                         </table>
//                     </td>
//                 </tr>
//                 <tr style="background-color:grey;" align="center" >
//                     <td style="padding: 20px; font-family: sans-serif; font-size: 12px; line-height: 15px; text-align: center; color: #ffffff;">
// 						Universitas Katolik Soegijapranata<br><span class="unstyle-auto-detected-links">Jl. Pawiyatan Luhur IV/1,<br>Bendan Duwur, Kec. Gajahmungkur, Kota Semarang, Jawa Tengah 50234<br>(024) 850-5003, (024) 850-0223</span>
//                         <br><br>
//                     </td>
//                 </tr>
//         </div>
// </body>
// </html>
// 			';
			// $mail->SMTPOptions = array(
			// 					'ssl' => array(
			// 						'verify_peer' => false,
			// 						'verify_peer_name' => false,
			// 						'allow_self_signed' => true
			// 					)
			// 				);
			// if(!$mail->send()){
			// 	echo "Mailer Error: " . $mail->ErrorInfo;
			// }else{
			// 	echo "Message sent!";
			// }
		}?>
</body>
</html>